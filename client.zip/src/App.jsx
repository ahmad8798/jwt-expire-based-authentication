import React from 'react'
import UserRegistration from './components/UserRegistration'
import UserLogin from './components/UserLogin'


const App = () => {
  return (
   <div style={{display:'flex',justifyContent:'space-between'}}>
      <UserRegistration/>
      <UserLogin/>
   </div>
  )
}

export default App
