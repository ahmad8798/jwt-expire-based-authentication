import axios from 'axios'
import React, { useState } from 'react'

const UserLogin = () => {
    const[formValues,setFormValues] = useState({email:'',password:''})
    const handleChange = (e) => {
        console.log(`form values before `,formValues)
        setFormValues({...formValues,[e.target.name]:e.target.value})
        console.log(`form values after`,formValues)
    }
    const sendRequest = async()=>{
        try{
            const{email,password} = formValues
            const response = await axios.post('http://localhost:7000/login',{email,password})
            console.log(response)
        }catch(err){
            console.log(err)
        }

    }
    const handleSubmit = (e)=>{
        e.preventDefault()
        sendRequest()
    }
  return (
 <>
    <div className="form">
      <form onSubmit={handleSubmit}>
            <label>Email:</label>
             <input onChange={handleChange} value={formValues.email} name='email' type="text" />
            <br />
            <label>Password:</label>
            <input onChange={handleChange} value={formValues.password} name='password' type="text"/>
            <br />
            <button type='submit'>Login</button>
        </form>
      </div>
 </>
  )
}

export default UserLogin
